// Accordion Widget
$(document).ready(function() {  
    $("#tabs").accordion({heightStyle: "content"});
});
