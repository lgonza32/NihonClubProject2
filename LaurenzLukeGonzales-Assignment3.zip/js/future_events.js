//superscrollorama jQuery plugin
$(document).ready(function() {  
    var controller = $.superscrollorama();
	// individual element tween examples
	controller.addTween('.upcoming_events', TweenMax.from( $('.upcoming_events'), 1, {css:{opacity: 0}}));
	controller.addTween('.past_events-1', TweenMax.from( $('.past_events-1'), 1, {css:{opacity: 0}}));
	controller.addTween('.past_events-2', TweenMax.from( $('.past_events-2'), 1.25, {css:{opacity: 0}}));
	controller.addTween('.past_events-3', TweenMax.from( $('.past_events-3'), 1.25, {css:{opacity: 0}}));
	controller.addTween('.past_events-4', TweenMax.from( $('.past_events-4'), 1.25, {css:{opacity: 0}}));
});



// $(document).ready(function() {  
//     // ScrollReveal().reveal('header');
//     // ScrollReveal().reveal('main', { delay: 500 });
//     // ScrollReveal().reveal('footer', { delay: 5000 });
//     ScrollReveal().reveal('header', {
//         delay: 300,
//         reset: true,
//         easing: 'ease-in'
//     });

//     ScrollReveal().reveal('#title', {
//         delay: 400,
//         reset: true,
//         easing: 'ease-in'
//     });

//     ScrollReveal().reveal('section', {
//         delay: 800,
//         interval: 500,
//         reset: true,
//         easing: 'ease-in'
//     });

//     ScrollReveal().reveal('footer', { 
//         delay: 500,
//         reset: true,
//         easing: 'ease-in' 
//     });

//     ScrollReveal().reveal('.facebook_icon', { 
//         delay: 600,
//         reset: true,
//         easing: 'ease-in' 
//     });

//     ScrollReveal().reveal('.instagram_icon', { 
//         delay: 700,
//         reset: true,
//         easing: 'ease-in' 
//     });

//     ScrollReveal().reveal('.discord_icon', { 
//         delay: 800,
//         reset: true,
//         easing: 'ease-in' 
//     });

//     ScrollReveal().reveal('.footer_nav', { 
//         delay: 850,
//         reset: true,
//         easing: 'ease-in' 
//     });

//     ScrollReveal().reveal('#copyright', { 
//         delay: 900,
//         reset: true,
//         easing: 'ease-in' 
//     });

//     ScrollReveal().reveal('#kitsune_head', { 
//         delay: 950,
//         reset: true,
//         easing: 'ease-in' 
//     });

//     ScrollReveal().reveal('hr', { 
//         delay: 800,
//         reset: true,
//         easing: 'ease-in'
//     });

//     ScrollReveal().reveal('.past_events', {
//         interval: 500,
//         reset: true,
//         easing: 'ease-in'
//     });
// });